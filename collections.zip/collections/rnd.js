const mongoose = require('mongoose');
const db = require('../db');

const RnDShowcaseSchema = new mongoose.Schema({
  year: {
    type: Number,
    required: true
  },
  locations: {
    type: String,
    required: true
  },
  technologies: [{
    type: mongoose.Schema.Types.ObjectId,
    ref : 'Technology'
  }],
  date: {
    type: Date,
  }
});

const RnDShowcase = db.model('RnD', RnDShowcaseSchema);

async function createRnDShowcase(data) {
    try {
      const showcase = new RnDShowcase(data);
      const result = await showcase.save();
      return result;
    } catch (error) {
      throw error;
    }
  }
  
  async function readRnDShowcase(id) {
    try {
      const result = await RnDShowcase.findById(id);
      return result;
    } catch (error) {
      throw error;
    }
  }
  
  async function updateRnDShowcase(id, data) {
    try {
      const result = await RnDShowcase.findByIdAndUpdate(id, data, { new: true });
      return result;
    } catch (error) {
      throw error;
    }
  }
  
  async function deleteRnDShowcase(id) {
    try {
      const result = await RnDShowcase.findByIdAndDelete(id);
      return result;
    } catch (error) {
      throw error;
    }
  }
  
  async function readRnDShowcases() {
    try {
      const result = await RnDShowcase.find();
      return result;
    } catch (error) {
      throw error;
    }
  }
  
  module.exports = { createRnDShowcase, readRnDShowcase, updateRnDShowcase, deleteRnDShowcase, readRnDShowcases };
